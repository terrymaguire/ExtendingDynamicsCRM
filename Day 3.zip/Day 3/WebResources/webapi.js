function onSave()
{
    var option = Xrm.Page.getAttribute("new_action").getValue();

    switch(option)
    {
        case 100000000: createAccount();
            break;
        case 100000001: retrieveAndUpdateAccount();
            break;
        case 100000002: retrieveAndDeleteAccount();
            break;
    }
}


function createAccount()
{
    //debugger;
    var clientURL = Xrm.Page.context.getClientUrl();

    var req = new XMLHttpRequest()
    req.open("POST", encodeURI(clientURL + "/api/data/v8.1/accounts"), true);
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.onreadystatechange = function () {     
        if (this.readyState == 4 /* complete */) {
            //debugger;
            req.onreadystatechange = null;
            if (this.status == 204) {
                var accountUri = this.getResponseHeader("OData-EntityId");
            }
            else {
                var error = JSON.parse(this.response).error;
            }
        }
    };

        var body = JSON.stringify({
            "name": "Extending WebAPI",
            "creditonhold": false,
            "address1_latitude": 47.639583,
            "description": "This is the description of the sample account",
            "revenue": 5000000,
            "accountcategorycode": 1
        });

        req.send(body);
}

function retrieveAndUpdateAccount() {

    //debugger;
    var clientURL = Xrm.Page.context.getClientUrl();

    var req = new XMLHttpRequest()
    req.open("GET", encodeURI(clientURL + "/api/data/v8.1/accounts?$filter=name eq 'Extending WebAPI'"), true);
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("OData-MaxVersion", "4.0");
   req.setRequestHeader("OData-Version", "4.0");
    req.onreadystatechange = function () {      
        if (this.readyState == 4 /* complete */) {
            //debugger;
            req.onreadystatechange = null;
            if (this.status == 200) {
                var data = JSON.parse(this.response);
                updateAccount(data.value[0].accountid);
            }
            else {
                var error = JSON.parse(this.response).error;
            }
        }
    };

    req.send();
}

function updateAccount(accountid)
{
    var clientURL = Xrm.Page.context.getClientUrl();

    var req = new XMLHttpRequest()
    req.open("PATCH", encodeURI(clientURL + "/api/data/v8.1/accounts("+accountid+")"), true);
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.onreadystatechange = function () {      
        if (this.readyState == 4 /* complete */) {
            //debugger;
            req.onreadystatechange = null;
            if (this.status == 204) {
                var data = JSON.parse(this.response);
            }
            else {
                var error = JSON.parse(this.response).error;
            }
        }
    };

    var body = JSON.stringify({
        "name": "Updated Extending WebAPI",
    });

    req.send(body);
}

function retrieveAndDeleteAccount()
{
    var clientURL = Xrm.Page.context.getClientUrl();

    var req = new XMLHttpRequest()
    req.open("GET", encodeURI(clientURL + "/api/data/v8.1/accounts?$filter=name eq 'Updated Extending WebAPI'"), true);
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.onreadystatechange = function () {
        if (this.readyState == 4 /* complete */) {
            //debugger;
            req.onreadystatechange = null;
            if (this.status == 200) {
                var data = JSON.parse(this.response);
                deleteAccount(data.value[0].accountid);
            }
            else {
                var error = JSON.parse(this.response).error;
            }
        }
    };

    req.send();
}

function deleteAccount(accountid)
{
    var clientUrl = Xrm.Page.context.getClientUrl();

    var req = new XMLHttpRequest()
    req.open("DELETE", encodeURI(clientUrl + "/api/data/v8.0/accounts("+accountid+")"), true);
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");

    req.send();
}
